# Inspect ID
Chrome extension to find what's behind an ID, because it can be annoying to read `0x9590b5fc46a499ad1f6k72d39b5334b1b4987fb3` without any connection to bubble

This extension connects to Alto bubble database using an n8n workflow. Later it will also integrate Alto postgres database.

# Instructions
- fill your APIKEY
- create a CORSanywher server and paste the adress
- 

# Credits
2023 @guillim
